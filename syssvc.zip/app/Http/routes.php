<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('principal');
});

Route::get('/clients/register', function () {
    return view('clients/registerClient');
});

Route::get('/dates/register', function () {
    return view('telemarketing/dates/createDate');
});

Route::get('/telemarketing/register', function () {
    return view('telemarketing/registerTelemark');
});

Route::get('/sellers/register', function () {
    return view('sellers/registerSeller');
});

Route::get('/clients/list', function () {
    return view('clients/listClients');
});

Route::get('/telemarketing/list', function () {
    return view('telemarketing/listTelemarketing');
});

Route::get('/sellers/list', function () {
    return view('sellers/listSellers');
});

Route::get('/dates/list', function () {
    return view('telemarketing/dates/listDates');
});

Route::get('/calls/list', function () {
    return view('telemarketing/calls/standbyCall');
});

Route::get('/clients/history', function () {
    return view('clients/seeHistory');
});

Route::get('/clients/referent', function () {
    return view('clients/createReferent');
});