 <!DOCTYPE html>
 <html lang="es">
 <head>
 	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 	<title>:: Sistema ::</title>
 	{!! Html::style('assets/css/bootstrap.min.css') !!}
 	<style>
 		iframe {
 			width: 100%;
 			height: 90vh;
 		}
 	</style>
 </head>
 <body>
 	<nav class="navbar navbar-inverse">
	  	<div class="container-fluid">
		    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">
			    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Desplegar Navegacion</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			    </button>
			    <a class="navbar-brand" href="#">Sistema de Seg. de Ventas y Clientes</a>
		    </div>

	    	<!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			    <ul class="nav navbar-nav">
			        <li class="active dropdown">
			        	<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Registrar <span class="caret"></span></a>
			        	<ul class="dropdown-menu">
			        		<li><a href="/clients/register" target="dashboard">Reg. Cliente</a></li>
			        		<li><a href="/telemarketing/register" target="dashboard">Reg. Telemarketing</a></li>
			        		<li><a href="/sellers/register" target="dashboard">Reg. Vendedor</a></li>
			        	</ul>
			        </li>
			        <li class="dropdown">
				        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Listar <span class="caret"></span></a>
				        <ul class="dropdown-menu">
				            <li><a href="/clients/list" target="dashboard">List. Clientes</a></li>
				            <li><a href="/telemarketing/list" target="dashboard">List. Telemarketing</a></li>
				            <li><a href="/sellers/list" target="dashboard">List. Vendedores</a></li>
				        </ul>
			        </li>
			        <li class="dropdown">
				        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Citas <span class="caret"></span></a>
				        <ul class="dropdown-menu">
				            <li><a href="/dates/register" target="dashboard">Generar Cita</a></li>
				             <li><a href="/dates/list" target="dashboard">Lista de Citas</a></li>
				        </ul>
			        </li>
			        <li class="dropdown">
				        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">LLamadas <span class="caret"></span></a>
				        <ul class="dropdown-menu">
				            <li><a href="/calls/list" target="dashboard">Pendientes de llamadas</a></li>
				        </ul>
			        </li>
			         <li class="dropdown">
				        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Referentes <span class="caret"></span></a>
				        <ul class="dropdown-menu">
				            <li><a href="/clients/history" target="dashboard">ver Historial</a></li>
				            <li><a href="/clients/referent" target="dashboard">Hacer Referente</a></li>
				        </ul>
			        </li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					
			    </ul>
		    </div><!-- /.navbar-collapse -->
	  	</div><!-- /.container-fluid -->
	</nav>
	<div class="container-fluid">
		<iframe src="" name="dashboard" frameborder="1"></iframe>
	</div>
 	{!! Html::script('assets/js/jquery.js') !!}
	{!! Html::script('assets/js/bootstrap.min.js') !!}
 </body>
 </html>